from django.shortcuts import render,HttpResponseRedirect
from .models import eBook,cart
from django.views.decorators.csrf import csrf_exempt

# Create your views here.
def store_view(request):

    ebook = {'ebook':eBook.objects.all()}
    return render(request, 'store/index.html',ebook)


def cart_view(request):
    CART_ITEMS = cart.objects.all()
    cart_total = 0
    for item in CART_ITEMS:
        cart_total += item.price
    return render(request, 'store/cart.html',{
        'cart_items' : CART_ITEMS,
        'cart_total' : round(cart_total,2),
    })



@ csrf_exempt
def add_cart_item(request):
    book_id = request.POST['book_id']
    title = eBook.objects.get(pk=book_id).title
    price = eBook.objects.get(pk=book_id).price
    item = cart.objects.create(title=title, price=price)
    return HttpResponseRedirect('/store')

@csrf_exempt

def del_cart_item(request):
    item_id = request.POST['item_id']
    cart.objects.get(pk=item_id).delete()
    return HttpResponseRedirect('/store/cart')


