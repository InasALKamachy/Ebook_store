from django.contrib import admin
from django.urls import path
from .views import store_view,cart_view,add_cart_item,del_cart_item


urlpatterns = [
    path('',store_view),
    path('cart_add_item/', add_cart_item),
    path('cart/', cart_view),
    path('cart/del_cart_item/', del_cart_item),

]